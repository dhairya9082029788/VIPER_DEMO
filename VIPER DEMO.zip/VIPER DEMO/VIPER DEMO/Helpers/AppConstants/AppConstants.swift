//
//  AppConstants.swift
//  VIPER DEMO
//
//  Created by Dhairya Vora on 28/08/22.
//

import Foundation

let authToken = "e23eb285110c4b61954c1a5fe6f5d31b"

let NEWS_URL = "https://newsapi.org/v2/top-headlines?sources=techcrunch&apiKey=e23eb285110c4b61954c1a5fe6f5d31b"

