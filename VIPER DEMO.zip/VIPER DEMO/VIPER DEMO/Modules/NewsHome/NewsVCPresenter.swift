//
//  NewsVCPresenter.swift
//  VIPER DEMO
//
//  Created by Dhairya Vora on 28/08/22.
//

import Foundation

//Protocol of the presenter
protocol NewsPresenterProtocol: AnyObject {
    func getHomeApiData()
    func redirectToDetails(newsUrl:String)
}

//Class of the News_Presenter
class NewsPresenter{
    weak var view: NewsViewProtocol?
    let interactor: NewsInteractorProtocol?
    let router: NewsRouterProtocol?
    
    init(view: NewsViewProtocol, interactor: NewsInteractorProtocol, router: NewsRouterProtocol){
        self.view = view
        self.interactor = interactor
        self.router = router
    }
}

//Instantiate of the Protocol into the class
extension NewsPresenter: NewsPresenterProtocol{
    func redirectToDetails(newsUrl:String) {
        router?.redirectToWebPage(newsUrl: newsUrl)
    }
    
    func getHomeApiData() {
        interactor?.fetchNewsApi(completion: { result in
            guard let responseData = result else {return}
            self.view?.getNewsFeed(data: responseData)
        })
    }
}

