//
//  NewsInteractor.swift
//  VIPER DEMO
//
//  Created by Dhairya Vora on 28/08/22.
//

import Foundation

//Protocol of the Interactor
protocol NewsInteractorProtocol: AnyObject {
    func fetchNewsApi(completion: @escaping (NewsFeedModel?) -> ())
}

//Instantiate of the interactor protocol into the class
class NewsInteractor: NewsInteractorProtocol{
    func fetchNewsApi(completion: @escaping (NewsFeedModel?) -> ()) {
        NewsDataManager.shared.NewsFeedManager() { result in
            switch result {
            case.success(let data):
                completion(data)
            case.failure(_):
                completion(nil)
                break
            }
        }
    }
}
