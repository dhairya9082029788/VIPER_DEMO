//
//  NewsTVC.swift
//  VIPER DEMO
//
//  Created by Dhairya Vora on 28/08/22.
//

import UIKit
import SDWebImage
import UIView_Shimmer

class NewsTVC: UITableViewCell {
    @IBOutlet weak var headerImage: UIImageView!
    @IBOutlet weak var titleLbl: UILabel!
    @IBOutlet weak var authorLbl: UILabel!
    @IBOutlet weak var descriptionLbl: UILabel!
    
    var shimmeringAnimatedItems: [UIView] {
        [
            headerImage,
            titleLbl,
            authorLbl,
            descriptionLbl
        ]
    }
    
    func loadData(data:Articles) {
        let headerImages = data.urlToImage ?? ""
        let newsHeader = URL(string: headerImages)
        self.titleLbl.text = data.title
        self.authorLbl.text = data.author
        self.descriptionLbl.text = data.description
        self.headerImage.sd_setImage(with: newsHeader)
        
    }
}
