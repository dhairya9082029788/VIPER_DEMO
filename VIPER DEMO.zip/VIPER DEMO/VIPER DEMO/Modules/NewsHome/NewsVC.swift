//
//  NewsVC.swift
//  VIPER DEMO
//
//  Created by Dhairya Vora on 28/08/22.
//

import UIKit

//View Controller Protocol
protocol NewsViewProtocol: AnyObject{
    func getNewsFeed(data:NewsFeedModel)
}

class NewsVC: UIViewController {
    @IBOutlet weak var activityIndicator: UIActivityIndicatorView!
    @IBOutlet weak var tableView: UITableView!
    
    var presenter: NewsPresenter?
    var newsFeedArray: [Articles] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        config()
        setupTableView()
        
    }
    
    private func setupTableView(){
        tableView.dataSource = self
        tableView.delegate = self
        tableView.register(UINib(nibName: "NewsTVC", bundle: nil), forCellReuseIdentifier: "NewsTVC")
    }
    
    private func config(){
        activityIndicator.startAnimating()
        presenter?.getHomeApiData()
    }
}

//MARK: - Extension of the TableView Delegate and Datasource
extension NewsVC: UITableViewDataSource, UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return newsFeedArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if let cell = tableView.dequeueReusableCell(withIdentifier: "NewsTVC") as? NewsTVC {
            cell.loadData(data: newsFeedArray[indexPath.row])
            return cell
        }
        return UITableViewCell()
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        presenter?.redirectToDetails(newsUrl: newsFeedArray[indexPath.row].url ?? "")
    }
}

//MARK: - Extension of the ViewController protocol
extension NewsVC: NewsViewProtocol {
    func getNewsFeed(data: NewsFeedModel) {
        self.newsFeedArray = data.articles ?? []
        DispatchQueue.main.async {
            self.activityIndicator.stopAnimating()
            self.activityIndicator.isHidden = true
            self.tableView.reloadData()
        }
    }
}
