//
//  NewsVCModuleBuilder.swift
//  VIPER DEMO
//
//  Created by Dhairya Vora on 28/08/22.
//

import Foundation
import UIKit

//Module Builder
class NewsVcModuleBuilder {
    static func build() -> UIViewController{
        let view = NewsVC()
        let interactor = NewsInteractor()
        let router = NewsRouter.init(view: view)
        let presenter = NewsPresenter.init(view: view, interactor: interactor, router: router)
        view.presenter = presenter
        return view
    }
}
