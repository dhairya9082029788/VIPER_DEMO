//
//  NewsVCRouter.swift
//  VIPER DEMO
//
//  Created by Dhairya Vora on 28/08/22.
//

import Foundation
import UIKit

//Protocol of the router
protocol NewsRouterProtocol: AnyObject{
    func redirectToWebPage(newsUrl:String)
}

//Class of the News_Router
class NewsRouter {
    var view: UIViewController
    init(view: UIViewController) {
        self.view = view
    }
}

//Instantiate of the router protocol into the class
extension NewsRouter: NewsRouterProtocol{
    func redirectToWebPage(newsUrl:String) {
        let vc = DetailsNewsModuleBuilder.build(factory: NavigationBuilder.build(viewController:), newsUrl: newsUrl)
        vc.modalPresentationStyle = .fullScreen
        view.present(vc, animated: true)
    }
}
