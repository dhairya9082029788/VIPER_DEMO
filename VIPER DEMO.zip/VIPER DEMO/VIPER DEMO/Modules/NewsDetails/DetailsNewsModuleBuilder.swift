//
//  DetailsNewsModuleBuilder.swift
//  VIPER DEMO
//
//  Created by Dhairya Vora on 28/08/22.
//

import Foundation
import UIKit

class DetailsNewsModuleBuilder {
    static func build(factory:NavigationFactory, newsUrl:String) -> UIViewController{
        let view = DetailsNewsVC()
        let interactor = DetailsNewsInteractor()
        let router = DetailsNewsRouter.init(view: view)
        let presenter = DetailsNewsPresenter.init(view: view, interactor: interactor, router: router)
        view.presenter = presenter
        view.newsUrl = newsUrl
        return view
    }
}

