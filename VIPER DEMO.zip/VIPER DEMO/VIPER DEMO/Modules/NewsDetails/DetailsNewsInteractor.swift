//
//  DetailsNewsInteractor.swift
//  VIPER DEMO
//
//  Created by Dhairya Vora on 28/08/22.
//

import Foundation

protocol DetailsNewsInteractorProtocol: AnyObject {
    func fetchNewsApi(completion: @escaping () -> ())
}

class DetailsNewsInteractor: DetailsNewsInteractorProtocol{
    func fetchNewsApi(completion: @escaping () -> ()) {
        //
    }
    
}
