//
//  DetailsNewsPresenter.swift
//  VIPER DEMO
//
//  Created by Dhairya Vora on 28/08/22.
//

import Foundation

protocol DetailsNewsPresenterProtocol: AnyObject {
   
}

class DetailsNewsPresenter{
    weak var view: DetailsNewsViewProtocol?
    let interactor: DetailsNewsInteractorProtocol?
    let router: DetailsNewsRouterProtocol?
    
    init(view: DetailsNewsViewProtocol, interactor: DetailsNewsInteractorProtocol, router: DetailsNewsRouterProtocol){
        self.view = view
        self.interactor = interactor
        self.router = router
    }
}

extension DetailsNewsPresenter: DetailsNewsPresenterProtocol{
    
}


