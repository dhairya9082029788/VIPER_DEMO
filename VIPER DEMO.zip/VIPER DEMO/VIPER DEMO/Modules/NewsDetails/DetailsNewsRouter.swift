//
//  DetailsNewsRouter.swift
//  VIPER DEMO
//
//  Created by Dhairya Vora on 28/08/22.
//

import Foundation
import UIKit

protocol DetailsNewsRouterProtocol: AnyObject{
    func redirectToWebPage()
}

class DetailsNewsRouter {
    var view: UIViewController
    init(view: UIViewController) {
        self.view = view
    }
}

extension DetailsNewsRouter: DetailsNewsRouterProtocol{
    func redirectToWebPage() {
      print("Hello")
    }
}

