//
//  NewsDataManager.swift
//  VIPER DEMO
//
//  Created by Dhairya Vora on 28/08/22.
//

import Foundation
import Alamofire

class NewsDataManager {
    static let shared = NewsDataManager()
    
    var contentDetails: ((NewsFeedModel) -> ())?
    
    func NewsFeedManager(completion: @escaping(ResultSet<NewsFeedModel ,ServerError>) -> Void){
        
        ServerDataManager.shared().getRequest(params: nil, apiPath: NEWS_URL) { result in
            switch result{
            case.success(let data):
                do{
                    let rootModel = try JSONDecoder().decode(NewsFeedModel.self, from: data)
                    completion(.success(rootModel))
                }catch{
                    print(error.localizedDescription)
                }
            case.failure(let error):
                completion(.failure(error))
                break
            }
        }
    }
}
